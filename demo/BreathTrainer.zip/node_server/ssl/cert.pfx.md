
With [chocolatey](https://chocolatey.org/install):

`choco install openssl` 

Then follow these instructions to create a .pfx file: [Quick Instructions](https://stackoverflow.com/questions/6307886/how-to-create-pfx-file-from-certificate-and-private-key)

Then place the new cert file in this folder.