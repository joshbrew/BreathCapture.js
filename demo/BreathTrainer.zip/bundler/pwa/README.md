## [Instructions](https://dev.to/digitalplayer1125/custom-service-worker-in-any-app-with-esbuild-3020)


### Compile & inject:

Required dependency:
`npm i workbox-cli`

Compile:
`workbox generateSW bundler/pwa/workbox-config.js`